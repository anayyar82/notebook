# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-lvis"
accountprovider_schema = StructType(
    [
        StructField("AccountID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Provider", StringType(), True),
        StructField("ProviderKey", StringType(), True),
        StructField("Details", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("Version", StringType(), True),
    ]
)
account_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("Version", StringType(), True),
    ]
)
providerkey_schema = StructType(
    [
        StructField("Provider", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("ProviderKey", StringType(), True),
        StructField("AccountID", StringType(), True),
        StructField("Details", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("Version", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["AccountProvider", "Account", "ProviderKey"]
schemas = [accountprovider_schema, account_schema, providerkey_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/lvis-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
