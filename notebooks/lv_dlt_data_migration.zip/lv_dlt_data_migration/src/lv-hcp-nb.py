# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-hcp"
asipregistry_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
    ]
)
hcp_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("LastLogin", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
hcppractice_schema = StructType(
    [
        StructField("HCPID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PracticeID", StringType(), True),
        StructField("Private", StringType(), True),
        StructField("IsAdmin", StringType(), True),
        StructField("Name", StringType(), True),
        StructField("Address1", StringType(), True),
        StructField("Address2", StringType(), True),
        StructField("City", StringType(), True),
        StructField("State", StringType(), True),
        StructField("ZipCode", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("PhoneNumber", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
hcppatient_schema = StructType(
    [
        StructField("HCPID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["ASIPRegistry", "HCP", "HCPPractice", "HCPPatient"]
schemas = [asipregistry_schema, hcp_schema, hcppractice_schema, hcppatient_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/hcp-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
