# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-partner"
partner_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("Enabled", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
partnerpatienthistory_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PartnerID", StringType(), True),
        StructField("UploadID", StringType(), True),
        StructField("Processed", StringType(), True),
        StructField("Retries", StringType(), True),
    ]
)
redoxpartneridmap_schema = StructType(
    [
        StructField("PartnerID", StringType(), True),
        StructField("RedoxID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("Updated", StringType(), True),
    ]
)
partnerpatientmailbox_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PartnerID", StringType(), True),
        StructField("UploadID", StringType(), True),
        StructField("FirstTimestamp", StringType(), True),
        StructField("LastTimestamp", StringType(), True),
        StructField("FactoryLastTimestamp", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("LockCreated", StringType(), True),
        StructField("Retries", StringType(), True),
    ]
)
cronjobaudit = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("CronID", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("D", StringType(), True),
        StructField("V", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
partneridmap_schema = StructType(
    [
        StructField("ExternalID", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("PartnerID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
partnerhistory_schema = StructType(
    [
        StructField("PartnerID", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("OldD", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["Partner", "PartnerPatientHistory", "RedoxPartnerIDMap", "PartnerPatientMailbox", "CronJobAudit", "PartnerIDMap", "PartnerHistory"]
schemas = [partner_schema, partnerpatienthistory_schema, redoxpartneridmap_schema, partnerpatientmailbox_schema, cronjobaudit, partneridmap_schema, partnerhistory_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/partner-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
