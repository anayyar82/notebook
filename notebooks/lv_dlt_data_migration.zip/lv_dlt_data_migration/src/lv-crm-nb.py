# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config

# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-crm"
accesscode_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("ContactID", StringType(), True),
        StructField("HCPID", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("Prefix", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("Language", StringType(), True),
        StructField("Status", StringType(), True),
        StructField("EmailsSent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
    ]
)
customer_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("CultureCode", StringType(), True),
        StructField("Product", StringType(), True),
        StructField("SourceSystem", StringType(), True),
        StructField("Sent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
    ]
)
hcp_schema = StructType(
    [
        StructField("HCPID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("AccessCode", StringType(), True),
        StructField("ContactID", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("Prefix", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("Language", StringType(), True),
        StructField("Activated", StringType(), True),
        StructField("Deleted", StringType(), True),
        StructField("PracticeName", StringType(), True),
        StructField("Address1", StringType(), True),
        StructField("Address2", StringType(), True),
        StructField("City", StringType(), True),
        StructField("State", StringType(), True),
        StructField("ZipCode", StringType(), True),
        StructField("PhoneNumber", StringType(), True),
        StructField("Sent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
    ]
)
permission_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("CommunicationChannel", StringType(), True),
        StructField("PermissionStatus", StringType(), True),
        StructField("Product", StringType(), True),
        StructField("SourceSystem", StringType(), True),
        StructField("Sent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
    ]
)
usage_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("UsageStatus", StringType(), True),
        StructField("Product", StringType(), True),
        StructField("FactoryTimestamp", StringType(), True),
        StructField("SourceSystem", StringType(), True),
        StructField("Sent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("DeviceID", StringType(), True),
        StructField("SerialNumber", StringType(), True),
        StructField("Activated", StringType(), True),
    ]
)

# COMMAND ----------
config = get_config(f'config/{database_name}-config.yaml')
tables = ["AccessCode", "Customer", "HCP", "Permission", "Usage"]
schemas = [accesscode_schema, customer_schema, hcp_schema, permission_schema, usage_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/crm-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
