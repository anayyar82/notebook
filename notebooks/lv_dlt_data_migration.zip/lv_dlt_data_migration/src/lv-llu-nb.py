# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-llu"
notificationtokenhash_schema = StructType(
    [
        StructField("Hash", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("TokenID", StringType(), True),
        StructField("TokenShardNbr", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
pushnotificationtoken_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("OldTokenID", StringType(), True),
        StructField("CareGiverID", StringType(), True),
        StructField("DeviceID", StringType(), True),
        StructField("Platform", StringType(), True),
        StructField("Token", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
connection_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("CareGiverID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
followerconnection_schema = StructType(
    [
        StructField("FollowerID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("D", StringType(), True),
        StructField("Updated", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["NotificationTokenHash", "PushNotificationToken", "Connection", "FollowerConnection"]
schemas = [notificationtokenhash_schema, pushnotificationtoken_schema, connection_schema, followerconnection_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/llu-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
