# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-messaging"
usermessage_schema = StructType(
    [
        StructField("AccountID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("MessageID", StringType(), True),
        StructField("Unread", StringType(), True),
        StructField("Timestamp", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("PracticeID", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
message_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["UserMessage", "Message"]
schemas = [usermessage_schema, message_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/messaging-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
