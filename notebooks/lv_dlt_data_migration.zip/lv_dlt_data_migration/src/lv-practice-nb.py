# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-practice"
practicepatientprogram_schema = StructType(
    [
        StructField("PracticeID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("ProgramID", StringType(), True),
        StructField("EvaluationType", StringType(), True),
        StructField("Sent", StringType(), True),
        StructField("EvaluationDate", StringType(), True),
    ]
)
invitation_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("EntityID", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("Expires", StringType(), True),
        StructField("ReceiverAccountID", StringType(), True),
        StructField("ReceiverEmail", StringType(), True),
        StructField("SenderAccountID", StringType(), True),
        StructField("Role", StringType(), True),
        StructField("Status", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
practicehcppatient_schema = StructType(
    [
        StructField("PracticeID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("HCPID", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Status", StringType(), True),
        StructField("LowGlucoseEventsInMgPerDl", StringType(), True),
        StructField("PercentGlucoseBelowTargetInMgPerDl", StringType(), True),
        StructField("PercentGlucoseInTargetInMgPerDl", StringType(), True),
        StructField("PercentGlucoseAboveTargetInMgPerDl", StringType(), True),
        StructField("LikelihoodLowGlucoseInMgPerDl", StringType(), True),
        StructField("SensorLowGlucoseEventsAvgDurationInMgPerDl", StringType(), True),
        StructField("PercentBelowHypoThresholdInMgPerDl", StringType(), True),
        StructField("PercentAboveHyperThresholdInMgPerDl", StringType(), True),
        StructField("AvgLowGlucoseEventsDayInMgPerDl", StringType(), True),
        StructField("LowGlucoseEventsInMmolPerL", StringType(), True),
        StructField("PercentGlucoseBelowTargetInMmolPerL", StringType(), True),
        StructField("PercentGlucoseInTargetInMmolPerL", StringType(), True),
        StructField("PercentGlucoseAboveTargetInMmolPerL", StringType(), True),
        StructField("LikelihoodLowGlucoseInMmolPerL", StringType(), True),
        StructField("SensorLowGlucoseEventsAvgDurationInMmolPerL", StringType(), True),
        StructField("PercentBelowHypoThresholdInMmolPerL", StringType(), True),
        StructField("PercentAboveHyperThresholdInMmolPerL", StringType(), True),
        StructField("AvgLowGlucoseEventsDayInMmolPerL", StringType(), True),
        StructField("Starred", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
practicedevice_schema = StructType(
    [
        StructField("PracticeID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("DeviceTypeID", StringType(), True),
        StructField("SerialNumber", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
practice_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Private", StringType(), True),
        StructField("Name", StringType(), True),
        StructField("Address1", StringType(), True),
        StructField("Address2", StringType(), True),
        StructField("City", StringType(), True),
        StructField("State", StringType(), True),
        StructField("ZipCode", StringType(), True),
        StructField("Country", StringType(), True),
        StructField("PhoneNumber", StringType(), True),
        StructField("BusinessID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
practicemember_schema = StructType(
    [
        StructField("PracticeID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("AccountID", StringType(), True),
        StructField("IsAdmin", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
businessidmap_schema = StructType(
    [
        StructField("BusinessID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PracticeID", StringType(), True),
        StructField("BusinessIDStatus", StringType(), True),
        StructField("Updated", StringType(), True),
    ]
)
practicepatient_schema = StructType(
    [
        StructField("PracticeID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("LastUpload", StringType(), True),
        StructField("AvgTestsPerDayInMgPerDl", StringType(), True),
        StructField("AvgGlucoseInMgPerDl", StringType(), True),
        StructField("AvgPostMealMorningInMgPerDl", StringType(), True),
        StructField("AvgPostMealMiddayInMgPerDl", StringType(), True),
        StructField("AvgPostMealEveningInMgPerDl", StringType(), True),
        StructField("AvgPostMealNightInMgPerDl", StringType(), True),
        StructField("AvgRapidActingInsulinInMgPerDl", StringType(), True),
        StructField("AvgLongActingInsulinInMgPerDl", StringType(), True),
        StructField("AvgInsulinDailyInMgPerDl", StringType(), True),
        StructField("StdDeviationInMgPerDl", StringType(), True),
        StructField("CoefficientVarianceInMgPerDl", StringType(), True),
        StructField("TotalGlucoseTestsInMgPerDl", StringType(), True),
        StructField("DaysWithoutGlucoseTestsInMgPerDl", StringType(), True),
        StructField("CalculatorUsageInMgPerDl", StringType(), True),
        StructField("PercentSensorDataCapturedInMgPerDl", StringType(), True),
        StructField("SensorDailyScansInMgPerDl", StringType(), True),
        StructField("InterquartileRangeInMgPerDl", StringType(), True),
        StructField("EstimatedA1cPercentInMgPerDl", StringType(), True),
        StructField("EstimatedA1cInMgPerDl", StringType(), True),
        StructField("AvgTestsPerDayInMmolPerL", StringType(), True),
        StructField("AvgGlucoseInMmolPerL", StringType(), True),
        StructField("AvgPostMealMorningInMmolPerL", StringType(), True),
        StructField("AvgPostMealMiddayInMmolPerL", StringType(), True),
        StructField("AvgPostMealEveningInMmolPerL", StringType(), True),
        StructField("AvgPostMealNightInMmolPerL", StringType(), True),
        StructField("AvgRapidActingInsulinInMmolPerL", StringType(), True),
        StructField("AvgLongActingInsulinInMmolPerL", StringType(), True),
        StructField("AvgInsulinDailyInMmolPerL", StringType(), True),
        StructField("StdDeviationInMmolPerL", StringType(), True),
        StructField("CoefficientVarianceInMmolPerL", StringType(), True),
        StructField("TotalGlucoseTestsInMmolPerL", StringType(), True),
        StructField("DaysWithoutGlucoseTestsInMmolPerL", StringType(), True),
        StructField("CalculatorUsageInMmolPerL", StringType(), True),
        StructField("PercentSensorDataCapturedInMmolPerL", StringType(), True),
        StructField("SensorDailyScansInMmolPerL", StringType(), True),
        StructField("InterquartileRangeInMmolPerL", StringType(), True),
        StructField("EstimatedA1cPercentInMmolPerL", StringType(), True),
        StructField("EstimatedA1cInMmolPerL", StringType(), True),
        StructField("LastLibreProReport", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("MiddleInitial", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("DOB", StringType(), True),
        StructField("LVAccount", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["PracticePatientProgram", "Invitation", "PracticeHCPPatient", "PracticeDevice", "Practice", "PracticeMember", "BusinessIDMap", "PracticePatient", ]
schemas = [practicepatientprogram_schema, invitation_schema, practicehcppatient_schema, practicedevice_schema, practice_schema, practicemember_schema, businessidmap_schema, practicepatient_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/practice-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
