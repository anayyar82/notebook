# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-patient"
gdprbacklog_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Processed", StringType(), True),
        StructField("Active", StringType(), True),
        StructField("Timestamp", StringType(), True),
    ]
)
partnernotification_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PartnerID", StringType(), True),
        StructField("Retry", StringType(), True),
        StructField("Message", StringType(), True),
    ]
)
patientsensor_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("SerialNumber", StringType(), True),
        StructField("Activated", StringType(), True),
        StructField("Ended", StringType(), True),
        StructField("D", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
patientpartnerconnection_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PartnerID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
patientconnectionhistory_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("FollowerID", StringType(), True),
        StructField("Action", StringType(), True),
        StructField("Status", StringType(), True),
        StructField("D", StringType(), True),
        StructField("Updated", StringType(), True),
    ]
)
measurement_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("DeviceID", StringType(), True),
        StructField("Timestamp", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("FactoryTimestamp", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("D", StringType(), True),
        StructField("UploadID", StringType(), True),
        StructField("RecordNumber", StringType(), True),
        StructField("TimestampOffset", StringType(), True),
    ]
)
patientconnection_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("FollowerID", StringType(), True),
        StructField("S", StringType(), True),
        StructField("SUpdated", StringType(), True),
        StructField("R", StringType(), True),
        StructField("RUpdated", StringType(), True),
        StructField("D", StringType(), True),
        StructField("Updated", StringType(), True),
    ]
)
patientupload_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("UploadID", StringType(), True),
        StructField("DeviceID", StringType(), True),
        StructField("DeviceTypeID", StringType(), True),
        StructField("TSMin", StringType(), True),
        StructField("TSMax", StringType(), True),
        StructField("FTSMin", StringType(), True),
        StructField("FTSMax", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
librelinksession_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("DeviceID", StringType(), True),
        StructField("DeviceTypeID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
patientpractice_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("PracticeID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

device_schema = StructType(
    [
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("ID", StringType(), True),
        StructField("DeviceTypeID", StringType(), True),
        StructField("SerialNumber", StringType(), True),
        StructField("LastUpload", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

patient_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("FirstName", StringType(), True),
        StructField("LastName", StringType(), True),
        StructField("Email", StringType(), True),
        StructField("LVAccount", StringType(), True),
        StructField("DOB", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["GdprBacklog", "PartnerNotification", "PatientSensor", "PatientPartnerConnection", "PatientConnectionHistory", "Measurement", "PatientConnection", "PatientUpload", "LibreLinkSession", "PatientPractice", "Device", "Patient"]
schemas = [gdprbacklog_schema, partnernotification_schema, patientsensor_schema, patientpartnerconnection_schema, patientconnectionhistory_schema, measurement_schema, patientconnection_schema, patientupload_schema, librelinksession_schema, patientpractice_schema, device_schema, patient_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/patient-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
