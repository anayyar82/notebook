# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-kpi"
event0_schema = StructType(
    [
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
event1_schema = StructType(
    [
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
event2_schema = StructType(
    [
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Created", StringType(), True),
    ]
)
dayevent0_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Date", StringType(), True),
    ]
)
dayevent1_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Date", StringType(), True),
    ]
)
dayevent2_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("EventType", StringType(), True),
        StructField("Event", StringType(), True),
        StructField("Date", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["Event0", "Event1", "Event2", "DayEvent0", "DayEvent1", "DayEvent2"]
schemas = [event0_schema, event1_schema, event2_schema, dayevent0_schema, dayevent1_schema, dayevent2_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/kpi-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
