# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------


raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-ldd"
diagnostics_schema = StructType(
    [
        StructField("InstallID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("CreatedBy", StringType(), True),
        StructField("Updated", StringType(), True),
        StructField("UpdatedBy", StringType(), True),
        StructField("V", StringType(), True),
        StructField("D", StringType(), True),
        StructField("P", StringType(), True),
    ]
)
libreprohash_schema = StructType(
    [
        StructField("SerialNumber", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Hash", StringType(), True),
    ]
)
uploadpayload_v2_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("AccountID", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("DeviceTimeOffsetMinutes", StringType(), True),
        StructField("Payload", StringType(), True),
        StructField("P", StringType(), True),
        StructField("StorageFormat", StringType(), True),
    ]
)

# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["Diagnostics", "LibreProHash", "UploadPayload_v2"]
schemas = [diagnostics_schema, libreprohash_schema, uploadpayload_v2_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/ldd-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
