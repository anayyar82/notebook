# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from lv_utils import generate_bronze_table, get_config
# COMMAND ----------

raw_data_path = spark.conf.get("raw_data_path")
catalog_name = "dev-adc-superiorlv-catalog-us-east-2"
database_name = "lv-event"
eventlog_schema = StructType(
    [
        StructField("ID", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("UserEvent", StringType(), True),
        StructField("Created", StringType(), True),
        StructField("D", StringType(), True),
    ]
)
pendingevent_schema = StructType(
    [
        StructField("PendingDate", StringType(), True),
        StructField("Type", StringType(), True),
        StructField("PatientID", StringType(), True),
        StructField("Shard", StringType(), True),
        StructField("D", StringType(), True),
    ]
)


# COMMAND ----------

config = get_config(f'config/{database_name}-config.yaml')
tables = ["EventLog", "PendingEvent"]
schemas = [eventlog_schema, pendingevent_schema]
for table, schema in zip(tables, schemas):
    table_hint = config[table]['table_hint']
    file_path = f"{raw_data_path}/event-1_{table}/*.tsv"
    generate_bronze_table(file_path, schema, table, table_hint)
